% set threshold parameters for colormap
% category variable should be set in environment

if strcmp(datacategory,'none')
    minthresh=0;
    imscale=1;
else
    imscale=54;
    if strcmp(datacategory,'ICC') % reliability map (0-1)
        minthresh=0.14; % user-defined
        maxthresh=.6; % user-defined
        
        ctitle='ICC';
        cmin=0.1;
        cmax=0.75;
        inc=0.1;
        cticklbls=[cmin:inc:cmax];
        
    elseif strcmp(datacategory,'scandur') % scan duration in runs (0-6)
        minthresh=1; % user-defined
        maxthresh=4.2; % user-defined
        unitinc=0.1; inc=1/unitinc; % user-defined
        maxthresh=maxthresh*inc;
        
        ctitle='min';
        cmin=0;
        cmax=6;
        
        runlength=6;
        cticklbls=[cmin:1:cmax]*runlength+runlength;
        
        cticklbls=sort(cticklbls,'descend');
        cticklbls=num2cell(cticklbls);
        cticklbls{1}='>36';
        
        cmax=cmax*inc;
        
        
    end
    
    imscale=imscale/(maxthresh-minthresh);
    cticks=([cmin:inc:cmax]-minthresh)*imscale;
    cylim=([cmin, cmax]-minthresh)*imscale;
end